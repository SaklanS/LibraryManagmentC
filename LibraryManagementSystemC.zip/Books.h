#ifndef BOOKS_H
#define BOOKS_H

void addBook();
void viewBooks();
void searchBook();
void deleteBook();
void editBook();
void borrowBook();
void returnBook();

#endif
