#include <stdio.h>
#include <stdlib.h>
#include "Books.h"

int main() {
    int choice;
    while(1) {
        printf("\nLibrary Management System\n");
        printf("1. Add Book\n");
        printf("2. View Books\n");
        printf("3. Search Book\n");
        printf("4. Delete Book\n");
        printf("5. Edit Book\n");
        printf("6. Borrow Book\n");
        printf("7. Return Book\n");
        printf("8. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch(choice) {
            case 1: addBook(); break;
            case 2: viewBooks(); break;
            case 3: searchBook(); break;
            case 4: deleteBook(); break;
            case 5: editBook(); break;
            case 6: borrowBook(); break;
            case 7: returnBook(); break;
            case 8: exit(0);
            default: printf("Invalid choice!\n");
        }
    }
    return 0;
}
