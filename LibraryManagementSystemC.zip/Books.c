#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Books.h"

// Define the structure for book information
struct Book {
    int id;
    char title[100];
    char author[100];
    int available;
};

struct Book books[100];
int bookCount = 0;

void addBook() {
    struct Book newBook;
    printf("Enter book ID: ");
    scanf("%d", &newBook.id);
    printf("Enter book title: ");
    scanf(" %[^
]s", newBook.title);
    printf("Enter book author: ");
    scanf(" %[^
]s", newBook.author);
    newBook.available = 1; // Set book as available
    books[bookCount++] = newBook;
    printf("Book added successfully!\n");
}

void viewBooks() {
    if (bookCount == 0) {
        printf("No books available.\n");
        return;
    }
    for (int i = 0; i < bookCount; i++) {
        printf("ID: %d, Title: %s, Author: %s, Available: %s\n", 
               books[i].id, books[i].title, books[i].author, 
               books[i].available ? "Yes" : "No");
    }
}

void searchBook() {
    char title[100];
    printf("Enter book title to search: ");
    scanf(" %[^
]s", title);
    for (int i = 0; i < bookCount; i++) {
        if (strcmp(books[i].title, title) == 0) {
            printf("ID: %d, Title: %s, Author: %s, Available: %s\n", 
                   books[i].id, books[i].title, books[i].author, 
                   books[i].available ? "Yes" : "No");
            return;
        }
    }
    printf("Book not found!\n");
}

void deleteBook() {
    int id;
    printf("Enter book ID to delete: ");
    scanf("%d", &id);
    for (int i = 0; i < bookCount; i++) {
        if (books[i].id == id) {
            for (int j = i; j < bookCount - 1; j++) {
                books[j] = books[j + 1];
            }
            bookCount--;
            printf("Book deleted successfully!\n");
            return;
        }
    }
    printf("Book not found!\n");
}

void editBook() {
    int id;
    printf("Enter book ID to edit: ");
    scanf("%d", &id);
    for (int i = 0; i < bookCount; i++) {
        if (books[i].id == id) {
            printf("Enter new title: ");
            scanf(" %[^
]s", books[i].title);
            printf("Enter new author: ");
            scanf(" %[^
]s", books[i].author);
            printf("Book details updated successfully!\n");
            return;
        }
    }
    printf("Book not found!\n");
}

void borrowBook() {
    int id;
    printf("Enter book ID to borrow: ");
    scanf("%d", &id);
    for (int i = 0; i < bookCount; i++) {
        if (books[i].id == id) {
            if (books[i].available) {
                books[i].available = 0;
                printf("Book borrowed successfully!\n");
            } else {
                printf("Book is already borrowed!\n");
            }
            return;
        }
    }
    printf("Book not found!\n");
}

void returnBook() {
    int id;
    printf("Enter book ID to return: ");
    scanf("%d", &id);
    for (int i = 0; i < bookCount; i++) {
        if (books[i].id == id) {
            if (!books[i].available) {
                books[i].available = 1;
                printf("Book returned successfully!\n");
            } else {
                printf("Book was not borrowed!\n");
            }
            return;
        }
    }
    printf("Book not found!\n");
}
